
SELECT
brand,
total_revenue
FROM
  sales,product limit 10