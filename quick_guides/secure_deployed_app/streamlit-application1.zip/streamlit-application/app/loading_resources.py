''''
This module retrieves values from the user's local storage and generates the app's first page
'''
# Importing required packages/modules and importing functions from app modules
import streamlit as st,time
from javascript import get_from_local_storage

def loading_resources():
    '''This function loads the values ("authenticated","userInfo") from the users browsers local storage 
        using get_from_local_storage() function'''
    
    with st.empty():  # Creates an empty container to clear with 'st.empty()' later 
        login_text_col = st.columns([0.5,1,0.5])
        with login_text_col[1]: 
                st.markdown("""<span style="font-family: 'Inter', sans-serif; font-size: 60px; display: flex; margin-left:-455px; margin-top: -80px;">Loading...</span>""", unsafe_allow_html=True)
                
                # Local Storage Calls
                
                auth_val=get_from_local_storage(key_name = "authenticated",key='a')
            
                user_info = get_from_local_storage(key_name = "userInfo",key='b')  
                # print("Userinfo:", user_info)
                # Exception for user_name variable , in case its not found
                try:
                    
                    user_name = user_info['id'] 
                
                    bearer_token = user_info['accessToken']
                except:
                    user_name = None
                    bearer_token = None
                
                time.sleep(1) # Extra time for javascript calls in case page load takes time (Reducing it below 2 sec may cause stutters in app)
        # Clears the screen for smooth page change effect 
        st.empty()  
    
    # print(f"Fetched values from Local storage are: \nUser Name: {user_name} \nAuthenticated: {auth_val} \nUser Info: {user_info} \nBearer Token: {bearer_token} ")
    return auth_val, user_info ,user_name, bearer_token