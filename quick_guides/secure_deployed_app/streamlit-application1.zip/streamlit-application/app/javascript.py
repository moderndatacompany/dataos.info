'''
This module comprises functions for executing JavaScript code for various use cases
'''

# Importing required packages/modules and importing functions from app modules
import streamlit as st,time,json
from streamlit_javascript import st_javascript

def nav_to(url):
    '''This function redirects user to the specified URL'''
    nav_script = """<meta http-equiv="refresh" content="0; url='%s'">""" % (url)
    st.write(nav_script, unsafe_allow_html=True)

def get_from_local_storage(key_name,key):
    '''This function fetched the specified field from Local Storage'''
    value = st_javascript(f"JSON.parse(localStorage.getItem('{key_name}'));",key=key)
    time.sleep(1)
    return value or {}

def set_to_local_storage_permanent(field, value):
    ''''This function adds a field to Local Storage'''
    filed_value = json.dumps(value)
    st_javascript(f"localStorage.setItem('{field}', JSON.stringify({filed_value}));")

def set_to_local_storage_timeout(field, value, timeout_minutes):
    '''This function adds a field to Local Storage and removes it after a specified time'''
    field_value = json.dumps(value)
    timeout_seconds = timeout_minutes * 60  # Convert minutes to seconds
    st_javascript(f"localStorage.setItem('{field}', JSON.stringify({field_value}));")
    st_javascript(f"setTimeout(function() {{localStorage.removeItem('{field}');}}, {timeout_seconds * 1000});")

def del_from_local_storage(field):
    '''This function deletes a key from Local Storage'''
    st_javascript(f"localStorage.removeItem('{field}');")

def del_local_storage_timeout(field, timeout_minutes):
    '''This function deletes a key from Local Storage after a specified time'''
    timeout_seconds = timeout_minutes * 60
    st_javascript(f"setTimeout(function() {{localStorage.removeItem('{field}');}}, {timeout_seconds * 1000});")
