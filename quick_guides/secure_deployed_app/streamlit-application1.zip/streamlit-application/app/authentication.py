'''
This module contains the code for the Authentication screen
'''

# Importing required packages/modules and importing functions from app modules
import streamlit as st, time, os, json
from javascript import set_to_local_storage_permanent, nav_to


def animated_progress_bar():
    '''This function creates the progress bar that we see on authentication screen'''

    # Custom Progress Bar CSS
    st.markdown(""" <style> .stProgress > div > div > div > div { background-color: #0192CD; height: 1px; width: 500px; max-width: 100%; } .stProgress > div > div > div { height: 1px; width: 500px; max-width: 50%; position: absolute; top: 50%; left: 50%; transform: translate(-50%, -50%); } </style>""",unsafe_allow_html=True)
    
    # Total time of progress bar in seconds
    completion_time = 5 
    progress_bar = st.progress(0)
    status_text = st.empty()

    # This loop create the percentage text beneath the progress bar
    for i in range(100):
        sleep_time = completion_time / 100  # Calculate sleep time per iteration
        time.sleep(sleep_time)
        progress_bar.progress(i + 1)
        status_text.markdown(f"<div style='font-family: Inter, sans-serif;padding-top:3px; font-size: 13px; color: var(--primaryTextColor); position: absolute; top: 50%; left: 50%; transform: translate(-50%, -50%);'>{i + 1}% Complete</div>",unsafe_allow_html=True)

# Calling Environment variable
file = open("/etc/dataos/config/secret.conf")
secret_json = json.load(file)

url = secret_json['DATAOS_ENV']

def authenticator(user_info, nav_url = url):
    '''This function compares the value of user_info variable value fetched from local storage in loading_resources.py
      and run conditions based on that.
      User will be redirected to DataOS Home page if he is not a user of DataOS or never performed DataOS login on UI for that environment
      otherwise user will be able to use the app'''
    
    # CSS for all elements
    st.markdown(f""" <style> @import url('https://fonts.googleapis.com/css2?family=Inter:wght@300&display=swap'); .login-text {{ font-family: 'Inter', sans-serif; font-weight: 300; font-size: 30px; color: var(--primaryTextColor); display: flex; justify-content: center; align-items: center; height: 100%;  }} .success-failure-text {{ font-family: 'Inter', sans-serif; font-weight: 300; font-size: 20px; color: color: var(--primaryTextColor); display: flex; justify-content: center; align-items: center; height: 100%; }} </style> """, unsafe_allow_html=True)
    
    login_text_col = st.columns([0.35,1.30,.35])
    with login_text_col[1]:
        
        # Header 1 
        st.markdown('<p class="login-text">Please wait, verifying your DataOS Credentials</p>', unsafe_allow_html=True)
        
        # Calling animated_progress_bar() function to create progress bar on screen after header
        animated_progress_bar()
        
        # Redirecting user to DataOS Home Page
        if user_info == {}:
            cred_success_col = st.columns([0.35,1.30,.35])
            st.write("")
            st.write("")
            
            # Redirect/ Login text  
            st.markdown('<p class="success-failure-text">Verification failed. Redirecting to DataOS Home Page</p>', unsafe_allow_html=True)
            time.sleep(1.5)

            # Navigating to DataOS Home Page
            nav_to(url=nav_url)
            
            print("\nAuthentication Failed, Redirecting User to DataOS Home page\n")
        else:
            # Sets authenticated variable in browsers local storage to True, this will prevent this functions execution for authenticated DataOS users
            set_to_local_storage_permanent('authenticated', True)
            
            cred_success_col = st.columns([0.35,1.30,.35])
            
            # Redirect/ Login text  
            with cred_success_col[1]:
                st.markdown('<p class="success-failure-text">Successfully verified. Starting the app</p>', unsafe_allow_html=True)
            
            print("\nSuccessfully verified. Starting the app\n")
            
            # Update Session State so that next page can be loaded
            st.session_state["page"] = 2
            
            print("\nPage value is now updated to 2\n")
            
            # Extra delay so that user can see Redirect/ Login text   
            time.sleep(2)
            st.rerun() 