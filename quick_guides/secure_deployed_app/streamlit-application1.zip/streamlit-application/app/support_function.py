import streamlit as st
import requests, base64

def get_svg_data_uri(svg_path):
    '''Function to read dataos logo (.svg format)'''
    with open(svg_path, 'rb') as file:
        svg_data = file.read()
        b64 = base64.b64encode(svg_data).decode("utf-8")
        data_uri = f"data:image/svg+xml;base64,{b64}"
    return data_uri

def set_stage(stage):
    'This function changes the values of stage variable of session state, helps in clearing the screen'
    st.session_state.stage = stage

# def job_status_workflow(dataos_token_user, wf_name, max_retries, retry_count):
     

def get_api_token(api_url, bearer_token):
    try:
        headers = {
            'Authorization': f'Bearer {bearer_token}',  # Include the bearer token in the headers
        }
        
        response = requests.get(api_url, headers=headers)
        response.raise_for_status()  # Raise an exception if the request fails

        # Parse the JSON response as a list
        data_list = response.json()

        # Check if the list is not empty
        if data_list and isinstance(data_list, list):
            # Assuming you want the first item in the list
            first_item = data_list[0]

            # Extract the 'api_key' from the 'data' field of the first item
            api_key = first_item.get('data', {}).get('apikey', '')

            return api_key
        else:
            st.error("Empty or invalid API response")
            return None
        
    except Exception as e:
                st.markdown(f"""
                    <style>
                    .title-container1 {{
                        display: flex;
                        justify-content: center;
                        align-items: center;
                        height: 10vh; /* Adjust the height as needed */
                        font-family: Inter, sans-serif;
                    }}
                    .title1 {{
                        font-size: 30px;
                    }}
                    .title-container2 {{
                        display: flex;
                        justify-content: center;
                        align-items: center;
                        height: 10vh; /* Adjust the height as needed */
                        font-family: Inter, sans-serif;
                    }}
                    .title2 {{
                        font-size: 30px;
                    }}
                    </style>
                    <div class="title-container1">
                        <div class="title1">Failed Fetching Data from the Server </div>
                    </div>
                    <div class="title-container2">        
                    <div class="title2">Please Login again</div>
                    </div>
                """, unsafe_allow_html=True)
                                    
    return None