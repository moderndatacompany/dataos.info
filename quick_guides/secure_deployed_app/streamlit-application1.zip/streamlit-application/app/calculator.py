import streamlit as st
from authentication import authenticator
from loading_resources import *
from support_function import get_svg_data_uri
import json
from heimdall.heimdall_client import HeimdallClientBuilder
from heimdall.models.authorization_request import AuthorizationRequest

# Set environment variable
with open("/etc/dataos/config/secret.conf") as file:
    secret_json = json.load(file)
dataos_env = secret_json['DATAOS_ENV']
heimdall_url = secret_json['API_ENDPOINT']

# Streamlit page configurations
st.set_page_config(layout='wide', page_title='Calculator', page_icon='icons/logo.png')

# Setting base CSS for the app
with open('css/base.css', 'r') as base_css_file:
    base_css = base_css_file.read()
st.markdown(f'<style>{base_css}</style>', unsafe_allow_html=True)

# Setting Session State Variables
if 'page' not in st.session_state:
    st.session_state.page = 0
if 'authorized' not in st.session_state:
    st.session_state.authorized = False

def authorize_user(heimdall_base_url, permissions, tab=""):
    '''Authorize the user using Heimdall'''
    auth_request = AuthorizationRequest(
        token=st.session_state.get('bearer_token', ''),
        permissions=permissions,
        context={
            "predicate": permissions[0],  # "get" , "put" or "post"
            "object": {
                "paths": ["/streamlit/**"]
            }
        }
    )
    try:
        # Initialize Heimdall client
        h_client = HeimdallClientBuilder().set_base_url(heimdall_base_url).build()
        # Send the authorization request to Heimdall
        auth_response = h_client.authorize_api.authorize(auth_request)

        # Check authorization results
        return auth_response.allow
    except Exception:
        st.write("Access Forbidden")
        return False

def addition_tab():
    '''This function handles addition operation'''
    with st.form("addition_form"):
        num1 = st.number_input("Enter first number", value=0.0, key="addition_num1")
        num2 = st.number_input("Enter second number", value=0.0, key="addition_num2")
        submitted = st.form_submit_button("Calculate")
        if submitted:
            result = num1 + num2
            st.write(f"Result: {result}")

def subtraction_tab():
    '''This function handles subtraction operation'''
    with st.form("subtraction_form"):
        num1 = st.number_input("Enter first number", value=0.0, key="subtraction_num1")
        num2 = st.number_input("Enter second number", value=0.0, key="subtraction_num2")
        submitted = st.form_submit_button("Calculate")
        if submitted:
            result = num1 - num2
            st.write(f"Result: {result}")

def multiplication_tab():
    '''This function handles multiplication operation'''
    if authorize_user(heimdall_url, ["view_multiplication"]):
        with st.form("multiplication_form"):
            num1 = st.number_input("Enter first number", value=0.0, key="multiplication_num1")
            num2 = st.number_input("Enter second number", value=0.0, key="multiplication_num2")
            submitted = st.form_submit_button("Calculate")
            if submitted:
                result = num1 * num2
                st.write(f"Result: {result}")
    else:
         st.write("You don't have access to open this tab")

def division_tab():
    '''This function handles division operation'''
    if authorize_user(heimdall_url, ["view_division"]):
        with st.form("division_form"):
            num1 = st.number_input("Enter first number", value=0.0, key="division_num1")
            num2 = st.number_input("Enter second number", value=0.0, key="division_num2")
            submitted = st.form_submit_button("Calculate")
            if submitted:
                if num2 != 0:
                    result = num1 / num2
                else:
                    result = "Error! Division by zero."
                st.write(f"Result: {result}")
    else:
         st.write("You don't have access to open this tab")

def app(user_name, bearer_token):
    '''Main app code with user authentication and additional features'''
    svg_data_uri = get_svg_data_uri('icons/logo_new.svg')
    help_icon = get_svg_data_uri('icons/question-circle.svg')

    with open('css/header.css', 'r') as header_css_file:
        header_css = header_css_file.read()
    st.markdown(f'<style>{header_css}</style>', unsafe_allow_html=True)

    st.title("Calculator")
    tabs = st.tabs(["Addition", "Subtraction", "Multiplication", "Division"])

    with tabs[0]:
        addition_tab()
    with tabs[1]:
        subtraction_tab()
    with tabs[2]:
        multiplication_tab()
    with tabs[3]:
        division_tab()

def main():
    '''Main function - orchestrator for app modules'''
    heimdall_base_url = heimdall_url

    if st.session_state["page"] == 0:
        user_name = ''
        bearer_token = ''
        local_storage_authentication, user_info, user_name, bearer_token = loading_resources()
        st.session_state.user_info = user_info
        st.session_state.username = user_name
        st.session_state.bearer_token = bearer_token

        if local_storage_authentication == {}:
            st.session_state["page"] = 1
        else:
            st.session_state["page"] = 2

    if st.session_state["page"] == 1:
        user_info = st.session_state.get('user_info')
        authenticator(user_info)
    elif st.session_state["page"] == 2:
        # Check if the user has "get" permission to access the application
        if authorize_user(heimdall_base_url, ["get"]):
            st.session_state["authorized"] = True
            app(st.session_state.get('username'), st.session_state.get('bearer_token'))
        else:
            st.write("You are not authorized to access this application. Please contact support")

if __name__ == "__main__":
    main()
