# Create a Data Products Interaction Map
Source-Aligned Data Products¶
Represent data as it exists in operational systems.
Consumer-Aligned Data Products¶
Transform and align data with the intended business use cases.
Define the flow: Sources → Source-Aligned DPs → Intermediate DPs → Consumer-Aligned DPs.
Map intermediate steps for seamless data transformation.
