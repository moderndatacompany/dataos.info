SELECT
    *
FROM
    schema.table_name