SELECT
    *
FROM
    public.product_data limit 1000